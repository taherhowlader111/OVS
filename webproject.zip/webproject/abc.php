<!DOCTYPE html>
<html>
<head>
	<title>Personal info</title>
	<meta charset="UTF-8"/>
	<link rel="stylesheet" type="text/css" href="st.css">
</head>
<body>
	
	
	<div class ="intro container ">
	   <div class ="intro_image">
	         <img src="images/img1.jpg">
			 
	     </div>	
        <div class ="intro_text">
           <h1> গণপ্রজাতন্ত্রী বাংলাদেশ সরকার <br> Government of the people’s Republic of Bangladesh </h1>
		        <h4>National ID Card / জাতীয় পরিচয় পত্র </h4>
        </div>
	</div>	
 
	
	<div class ="content container ">
	   
		     
		
	    <div class ="content_text ">
		      
		     <background src="images/img2.png">
<p>			 
<?php
include("conn.php");

$sql = "SELECT NID FROM database1";
$flag = 1;
$result = $conn->query($sql);
$fn = $_POST["fn"];
$sq = "SELECT * FROM database1 WHERE NID=$fn";


		while($row = $result->fetch_assoc()){
		
		if($row["NID"] == $fn){
        $re = $conn->query($sq);
		$ro = $re->fetch_assoc();
		echo "National Id card No: ".$ro["NID"]."<br>";
		echo "First Name: ".$ro["First_Name"]."<br>";
		echo "Last Name: ".$ro["Last_Name"]."<br>";
		echo "Father's Name: ".$ro["Fathers_Name"]."<br>";
		echo "Mother's Name: ".$ro["Mothers_Name"]."<br>";
		echo "Contact Number: ".$ro["Mobile"]."<br>";
		echo "Address: ".$ro["Address"]."<br>";
		echo "Blood Group: ".$ro["Blood_Group"]."<br>";
		
		$flag++;
		}		
}
if($flag==1){
	echo "No Result Found<br>";
}
 
$conn->close();
?>
</p>

<?php
echo "<br>".'<img src="data:image/jpeg;base64,'.$ro['Photo'].'"/>';
?>
	    
	</div>
	
	</div>
	
	<div class ="footer container ">
	
	       <div class="footer_animation">
		   <marquee ><h5> Welcome to our Website </h5></marquee>
		   
		   
		   
	     </div>
	</div>
	    
</body>
</html>