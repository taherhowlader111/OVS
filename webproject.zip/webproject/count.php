<?php
include("conn.php");

session_start();
$aa=$_SESSION['a'];

$fn = $_POST['cand'];
$sql = "SELECT Vote FROM candidate WHERE Id= $fn";
$result = $conn->query($sql);
$ro = $result->fetch_assoc();
$v = $ro["Vote"];

if(isset($_POST['cand']))
{
	if($_POST['cand'] == "1"){
		$v++;
		$conn->query("UPDATE candidate SET Vote=$v WHERE Id=1");
		echo "Vote Successful";
	}
	else if($_POST['cand'] == "2"){
		$v++;
		$conn->query("UPDATE candidate SET Vote=$v WHERE Id=2");
		echo "Vote Successful";
	}
	else if($_POST['cand'] == "3"){
		$v++;
		$conn->query("UPDATE candidate SET Vote=$v WHERE Id=3");
		echo "Vote Successful";
	}
	else if($_POST['cand'] == "4"){
		$v++;
		$conn->query("UPDATE candidate SET Vote=$v WHERE Id=4");
		echo "Vote Successful";
	}
	echo $aa;
	$sq = "SELECT Flag FROM database1 WHERE NID= $aa";
	$re = $conn->query($sq);
	$r = $re->fetch_assoc();
	$w = $r["Flag"];
	$w++;
	$conn->query("UPDATE database1 SET Flag=$w WHERE NID=$aa");
}

$conn->close();
?>