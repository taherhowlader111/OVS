<!DOCTYPE html>
<html>
<head>
	<title>Personal info</title>
	<meta charset="UTF-8"/>
	<link rel="stylesheet" type="text/css" href="st.css">
</head>
<body>
	
	
	<div class ="intro container ">
	   <div class ="intro_image">
	         <img src="images/img1.jpg">
			 
	     </div>	
        <div class ="intro_text">
           <h1> গণপ্রজাতন্ত্রী বাংলাদেশ সরকার <br> Government of the people’s Republic of Bangladesh </h1>
		        <h4>National ID Card / জাতীয় পরিচয় পত্র </h4>
        </div>
	</div>	
 
	
	<div class ="content container ">
	   
		     
		
	    <div class ="content_text ">
		      
		     <background src="images/img2.png">


<?php
include("conn.php");

session_start();
$_SESSION['a']=$_POST['fn'];

$f = $_POST['fn'];
$sql = "SELECT Flag FROM database1 WHERE NID= $f";
$result = $conn->query($sql);
$ro = $result->fetch_assoc();
$v = $ro["Flag"];
$noid = 0;
$noidlog = 0;
$sq = "SELECT NID FROM database1";
$re = $conn->query($sq);

while($row = $re->fetch_assoc()){
	if($row["NID"] == $f){
		if(isset($_POST['fn'])){
			$noidlog = 1;
	if($v == "0"){
		
		
		
		echo '<form action="count.php" method="post">
<h1><table style="width:100%">
  <tr>
    <td><input type="radio" name="cand" value="1"> Md. Mohaimenul Reza<br></td>
    <td><img src="images/cherry.png" style="width:200px;height:200px;"></td>
  </tr>
  <tr>
<td><input type="radio" name="cand" value="2"> Taher Howlader Shohan<br></td>
<td><img src="images/apple.png" style="width:200px;height:200px;"></td>
  </tr>
    <tr>
<td><input type="radio" name="cand" value="3"> Sazzad Hossain Saju<br></td>
<td><img src="images/mango.jpg" style="width:200px;height:200px;"></td>
  </tr>
    <tr>
<td><input type="radio" name="cand" value="4"> Shirin Sultana<br></td>
<td><img src="images/watermelon.jpg" style="width:200px;height:200px;"></td>
  </tr>
</table></h1>
<input type="Submit">
</form> ';
		
	}else{
	 echo "You already Did Your Vote";
	}
	
}
	}else {
		$noid++;
	}
	
}
if($noid>0 && $noidlog==0){
		echo "No Id Found";
	}



$conn->close();
?>





	    
	</div>
	
	</div>
	
	<div class ="footer container ">
	
	       <div class="footer_animation">
		   <marquee ><h5> Welcome to our Website </h5></marquee>
		   
		   
		   
	     </div>
	</div>
	    
</body>
</html>