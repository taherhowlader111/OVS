<?php
include("conn.php");

$sql = "SELECT NID FROM database1";
$result = $conn->query($sql);
$fn = $_POST["fn"];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		if($row["NID"] == $fn){
        echo "Login Sucessfull";
		}
	}		
}
 else {
    echo "No Result Found";
}
$conn->close();
?>