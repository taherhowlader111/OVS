<?php

include("conn.php");

$id = $_POST["id"];
$fn = $_POST["fn"];
$ln = $_POST["ln"];
$fan = $_POST["fan"];
$mn = $_POST["mn"];
$con = $_POST["con"];
$add = $_POST["add"];
$bg = $_POST["bg"];
$image= addslashes($_FILES['image']['tmp_name']);
$image= file_get_contents($image);
$image= base64_encode($image);
					
					
$sql = "INSERT INTO database1 VALUES ('$id','$fn','$ln','$fan','$mn','$con','$add','$bg','$image','0')";


if ($conn->query($sql) === TRUE) {
    echo "Successfully ";
	$code = mt_rand();
	$user = "ovs111";
	$password = "ovs111";
	$postUrl =  "https://api.infobip.com/sms/1/text/single"; 
	$ch = curl_init();
	$header = array("Content-Type:application/json", "Accept:application/json");
	$data = array(
		'form'=>'OVS',
		'to' => $con,
		'text'=>'This PIN number is very secret.So do not share to other:'.$code,
	);

	curl_setopt($ch, CURLOPT_URL, $postUrl); 
	curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	curl_setopt($ch, CURLOPT_USERPWD, $user . ":" . $password);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	curl_setopt($ch, CURLOPT_MAXREDIRS, 2);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // response of the POST request 
	$result = curl_exec($ch); 
	if ($result === FALSE) { die('Curl Faild: ' . curl_error($ch)); }
	curl_close($ch);
	
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>